package com.nicosandoval.ArquitecturaHexagonal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArquitecturaHexagonalApplicationTests {

	@Test
	void contextLoads() {
	}

}
